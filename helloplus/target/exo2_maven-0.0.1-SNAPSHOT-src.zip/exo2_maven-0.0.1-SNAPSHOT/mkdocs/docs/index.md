# Documentation Hello+



## Que fait le programme ? 

Il affiche des messages du type "Hello !" où la liste des noms et des prénoms est stockée dans un fichier au format CSV.

L'application utilise les API Apache suivantes : Apache Commons CLI/ Apache Commons CSV



## Auteur

Guillaume Reinert


## Licence

Ce projet est distribué sous la licence GNU GPL 3.